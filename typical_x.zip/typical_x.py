import xlwings as xw
from ortoolpy.optimization import *

def doit(com, res_label='Result'):
    wb = xw.Book.caller()
    sh = wb.sheets[0]
    rn = sh[res_label]
    rn.expand().clear()
    rn.value = eval(com)
    rn.value = '結果'

