import xlwings as xw
from ortoolpy.optimization import *

def doit(com):
    wb = xw.Book.caller()
    sh = wb.sheets[0]
    rn = sh['E2']
    rn.expand().clear()
    rn.value = eval(com)
    rn.value = '結果'

